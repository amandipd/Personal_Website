package com.amandip.photo._clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotosCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
